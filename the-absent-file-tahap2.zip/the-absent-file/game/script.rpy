# script.rpy - kerangka awal (Tahap 2)
# Label "start" adalah titik mulai saat New Game.

label start:

    scene bg room with fade

    "THE ABSENT FILE"
    "Sebelum mulai, siapa namamu?"

    $ pname = renpy.input("Masukkan nama (maks. 16 huruf):", length=16).strip()
    if not pname:
        $ pname = "Alex"

    mc "Namaku [pname]."

    scene bg archive with dissolve

    arman "Selamat datang. Ini hanya uji kerangka proyek."
    reina "You came earlier this time."

    # Uji variabel: akan dipakai di tahap berikutnya
    "Variabel siap: evidence=[evidence], reina_bond=[reina_bond]."
    "Kerangka Tahap 2 berjalan. Cerita sebenarnya dimulai di Tahap 3."

    return
