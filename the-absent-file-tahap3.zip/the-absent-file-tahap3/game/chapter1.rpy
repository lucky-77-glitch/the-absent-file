# chapter1.rpy - SEMENTARA (stub) sampai Tahap 4

label chapter1:

    $ current_chapter = "Chapter 1"

    scene bg archive with fade

    "Chapter 1 will be written in Stage 4."
    "Debug: evidence=[evidence], independence=[independence], kept_letter=[kept_letter], photo_checked=[photo_checked]."
    "Debug: clue_letter=[clue_letter], checked_hallway=[checked_hallway], checked_envelope=[checked_envelope]."

    return
