# characters.rpy - definisi karakter

define mc = Character("[pname]", color="#c9d1d9")
define arman = Character("Arman", color="#8fa8c8")
define reina = Character("Reina", color="#b04a5a")
define narrator_thought = Character(None, what_italic=True)

# Latar placeholder sederhana (ganti dengan gambar milik sendiri nanti)
image bg room = Solid("#14161c")
image bg archive = Solid("#10141a")
image bg street = Solid("#0c0e13")
