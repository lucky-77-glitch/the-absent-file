# options.rpy - pengaturan dasar proyek
# PERHATIAN: jangan ubah config.save_directory setelah game dirilis.

define config.name = _("THE ABSENT FILE")
define gui.show_name = True
define config.version = "0.1.0"

define gui.about = _p("""
Visual novel psychological horror.
""")

define build.name = "TheAbsentFile"

define config.has_sound = True
define config.has_music = True
define config.has_voice = False

define config.save_directory = "TheAbsentFile-1"

# Autosave bawaan Ren'Py
define config.has_autosave = True
define config.autosave_frequency = 200
define config.quicksave_slots = 1
