# prologue.rpy - Prologue: The Letter

label prologue:

    $ current_chapter = "Prologue"

    scene bg room with fade
    pause 0.5

    "Rain. Past midnight."
    "The apartment is quiet in the way only an empty place can be quiet."
    "Then, a soft scrape at the front door."
    "Something has been pushed underneath it."
    "A plain white envelope. No name. No stamp."

    menu:
        "What do you do?"

        "Pick it up and open it.":
            mc "Nobody sends mail at this hour."
            "You tear the flap open."

        "Leave it on the floor until morning.":
            "You step over it and make tea you never drink."
            "By the time the cup is cold, the envelope has not moved. Neither has your curiosity."
            "You pick it up. You open it."

    "Inside is a single photograph, printed on cheap paper."
    "A windowless archive room. Steel shelves. Two chairs facing each other, both empty."
    "On the back, in neat block letters:"
    "{i}\"You were there. Ask them why they erased you.\"{/i}"

    mc "I have never been in a place like that."

    menu:
        "The photograph waits in your hand."

        "Study the photograph closely.":
            $ photo_checked = True
            $ evidence += 1
            $ clue_letter = True
            "You hold it under the lamp."
            "A sign on the top shelf: {i}UNIT 6{/i}. A date stamp on the wall, too blurred to read."
            "The two chairs are aligned exactly, as if someone measured the distance between them."
            mc "Someone stood right here to take this."

        "Glance at it and set it aside.":
            "You have seen enough. Rooms are only rooms."
            "Still, the two empty chairs stay with you, like an afterimage behind your eyes."

    menu:
        "Who sent this?"

        "Check the hallway.":
            $ checked_hallway = True
            $ evidence += 1
            "You open the door. The corridor is empty."
            "A narrow line of floor is dry, from the stairs to your door, though the rain has soaked everything else."
            "Someone walked here. Or someone was already inside the building."

        "Examine the envelope for marks.":
            $ checked_envelope = True
            $ evidence += 1
            "Under the flap, in faint pencil, you find a single digit: {i}6{/i}."
            mc "Six. Like the sign in the photo."

        "It doesn't matter who sent it.":
            $ independence += 1
            mc "If it matters, they will come back."
            "The words sound braver than you feel."

    menu:
        "What do you do with the letter?"

        "Keep it.":
            $ kept_letter = True
            "You slide the envelope into the drawer with your important papers."
            "It feels strange to treat it as important."

        "Throw it away.":
            $ independence += 1
            "You drop it in the bin. The photograph lands face up."
            "The two chairs look back at you."

    scene black with dissolve
    pause 0.5
    scene bg room with dissolve

    "You know there is only one archive in the district that still keeps paper records."
    "National Archive Unit 6."

    menu:
        "The night is not over."

        "Go to the archive now.":
            "You find your coat and leave the lights on, as if you plan to come back soon."

        "Sleep first. Go in the morning.":
            "You do not sleep. You lie still and count the seconds between raindrops."
            "At dawn you give up and get dressed."

        "Refuse to be led around by an anonymous note.":
            $ independence += 1
            mc "I am not going anywhere."
            "Twenty minutes later, you are lacing your shoes."

    scene black with fade
    "End of Prologue."

    jump chapter1
