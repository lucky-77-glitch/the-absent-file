# script.rpy - titik mulai game
# Label "start" dijalankan saat New Game.

label start:

    scene black with fade

    "THE ABSENT FILE"

    $ pname = renpy.input("Enter your name (max 16 letters):", length=16).strip()
    if not pname:
        $ pname = "Alex"

    jump prologue
