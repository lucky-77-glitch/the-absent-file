# variables.rpy - semua variabel cerita (tersimpan otomatis di save)

# Nama protagonis (diisi pemain di awal game)
default pname = "Alex"

# Bab yang sedang dimainkan (dipakai untuk info save nanti)
default current_chapter = "Prologue"

# Skor jalur cerita
default evidence = 0
default reina_bond = 0
default arman_susp = 0
default independence = 0

# Bendera tindakan (False = belum dilakukan)
default kept_letter = False
default photo_checked = False
default checked_hallway = False
default checked_envelope = False
default asked_log = False
default followed_reina = False
default photographed_redaction = False
default hid_document = False
default shared_with_arman = False
default shared_with_reina = False

# Petunjuk CASE FILES (False = masih terkunci)
default clue_letter = False
default clue_log = False
default clue_inventory = False
default clue_redacted = False

# Koleksi ending: terpisah dari save slot, tidak dihapus saat New Game
default persistent.endings_seen = set()
