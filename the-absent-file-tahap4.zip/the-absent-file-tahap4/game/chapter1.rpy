# chapter1.rpy - Chapter 1: The Invitation
# Arman: formal, tenang, kalimat pendek. Reina: santai, terputus-putus, menggoda.

label chapter1:

    $ current_chapter = "Chapter 1"

    scene bg archive with fade
    pause 0.5

    "National Archive Unit 6 stands at the end of a street the rain has forgotten."
    "Inside, the lights hum at a pitch you can feel in your teeth."
    "Behind a long counter, a tall figure sits perfectly still."

    show arman at center with dissolve

    arman "Unit 6 closes in ten minutes. State your business."

    menu:
        "How do you start?"

        "Ask directly about FILE 00.":
            $ asked_file00 = True
            $ arman_susp += 1
            mc "I am here about FILE 00."
            arman "There is no FILE 00."
            arman "I would remember. I remember everything filed in this building."
            mc "That is not what I asked."
            arman "It is the only answer I have."

        "Say you are here to research old records.":
            $ hid_purpose = True
            mc "I am researching old records. Nothing in particular."
            arman "Everything here is old. Most of it is nothing in particular."
            arman "Be specific, or be brief."

        "Show him the photograph." if kept_letter:
            $ shared_with_arman = True
            $ evidence += 1
            "You place the photograph on the counter."
            arman "..."
            "For two full seconds, he does not move. Not even breathing."
            with hpunch
            arman "That room was decommissioned."
            arman "Decommissioned rooms do not appear in photographs."
            mc "Then who took this?"
            arman "Someone who should not have."

    jump arman_hub


label arman_hub:

    if arman_susp >= 3:
        arman "You ask many questions, [pname]. I have noted that."

    menu:
        "What now?"

        "Ask about FILE 00." if not asked_file00:
            $ asked_file00 = True
            $ arman_susp += 1
            mc "Tell me about FILE 00."
            arman "There is nothing to tell. It does not exist."
            mc "Then why does everyone say the name like it does?"
            arman "People say many names. That does not make them real."
            jump arman_hub

        "Ask to see the visitor log." if not asked_log:
            $ asked_log = True
            mc "May I see the visitor log?"
            arman "It is public. Page forty-one."
            "The ledger is heavy, its cloth cover gone grey with handling."
            "Three months ago. One line of ink. Your name, in your handwriting."
            $ clue_log = True
            $ evidence += 1

            menu:
                "Your own name is on this page."

                "I found my name in the visitor log.":
                    $ evidence += 1
                    mc "I found my name in the visitor log."
                    arman "Yes."
                    arman "You signed in three months ago. You signed out forty minutes later."
                    arman "You requested nothing. I have no record of what you did in between."

                "Maybe I came here before.":
                    $ arman_susp -= 1
                    mc "Maybe I came here before."
                    arman "Many do. Archives are forgettable places."
                    arman "That is not a criticism. It is a design."

                "Why are you lying to me?":
                    $ arman_susp += 2
                    mc "Why are you lying to me?"
                    arman "I do not lie. I file."
                    arman "If a thing is not filed, it is not true. That is not my rule. It is the building's."

                "Forget it. I should not have asked.":
                    mc "Forget it. I should not have asked."
                    arman "You should not have. But you did."
                    arman "That is also recorded."

            jump arman_hub

        "Test his story." if not tested_arman:
            $ tested_arman = True

            menu:
                "How do you test him?"

                "Point out the blank nameplate on the east shelf.":
                    $ evidence += 1
                    $ arman_susp += 1
                    mc "Then why is there a blank nameplate at the start of the east shelf?"
                    arman "Nameplates wear out. Numbers are reassigned."
                    arman "A gap is not a box."

                "Ask him to repeat what he said, word for word.":
                    $ arman_susp += 1
                    mc "Say it again. Exactly what you told me."
                    arman "There is no FILE 00."
                    "The same pause. The same breath. Like a recording played twice."

            jump arman_hub

        "Ask for his help." if not asked_help:
            $ asked_help = True
            $ got_slip = True
            mc "Could you help me look? I do not even know where to start."
            arman "Staff may assist with requests that are submitted properly."
            "He slides a printed slip across the counter. REQUEST FOR ACCESS."
            arman "Fill it out. I will not read what you write."
            arman "I will, however, remember that you asked."
            jump arman_hub

        "Pretend to believe him." if not pretended_belief:
            $ pretended_belief = True
            $ arman_susp -= 1
            mc "You are right. I must have been confused."
            arman "Confusion is common."
            "He nods slowly. Something in his posture loosens by a fraction."
            arman "Good. Then we understand each other."
            jump arman_hub

        "Thank him and go outside.":
            mc "Thank you for your time."
            if asked_log:
                arman "Come again, [pname]. You know the way."
            else:
                arman "Come again, [pname]."
                "You never told him your name."
            jump chapter1_outside

        "Say nothing more. Walk away and investigate alone.":
            $ independence += 1
            "You turn your back on him."
            "You can feel his gaze on your coat all the way to the door."
            jump chapter1_outside


label chapter1_outside:

    hide arman with dissolve
    scene bg street with fade
    pause 0.5

    "Rain has turned the pavement into a black mirror."
    "Someone is waiting under the broken streetlight."

    show reina at center with dissolve

    reina "You came earlier this time."

    menu:
        "How do you answer?"

        "Smile. \"Do I know you?\"":
            $ reina_bond += 1
            mc "Do I know you?"
            reina "Hm. Maybe. Maybe not."
            reina "Funny, though. You look at me like you are checking a list."

        "\"What do you mean, earlier?\"":
            $ evidence += 1
            mc "What do you mean, earlier?"
            reina "Hm?"
            reina "I did not say anything."
            "She did. You are certain. But her face is blank, like a page waiting for ink."

        "\"I do not talk to strangers.\"":
            $ reina_bond -= 1
            mc "I do not talk to strangers."
            reina "Ha. Good rule."
            reina "Funny how strangers keep talking to you anyway."

        "\"I think I have lost three months.\"":
            $ reina_bond += 2
            mc "I think I have lost something. Three months, maybe."
            reina "..."
            reina "Do not say that so loud. Not out here."
            "Her voice drops. For a moment she sounds like the one who is afraid."

        "\"You said it like we had met. Do not deny it.\"":
            $ reina_bond -= 1
            $ evidence += 1
            mc "You said it like we had met. Do not deny it."
            reina "I deny nothing."
            reina "I just do not remember anything. It is a very easy way to live."

    reina "You were inside. Did he tell you it does not exist?"

    menu:
        "How much do you tell her?"

        "Tell her everything Arman said.":
            $ shared_with_reina = True
            $ reina_bond += 1
            "You repeat his words, one by one."
            reina "Same words. Same order."
            reina "Funny, no?"

        "Show her the photograph." if kept_letter:
            $ shared_with_reina = True
            $ evidence += 1
            $ reina_bond += 1
            "You hold the photograph out. Rain beads on the paper."
            reina "..."
            reina "The chairs. They were not that far apart."
            "She catches herself, too late."
            reina "I mean... I would not know that."

        "Tell her nothing.":
            $ independence += 1
            mc "Why do you want to know?"
            reina "Smart. Or scared."
            reina "From the outside, they look the same."

    if reina_bond >= 3:
        reina "If you want to find out what is real, come back tomorrow. I will be here. I think."
    elif reina_bond <= 0:
        reina "Fine. Be difficult. Everyone is, the second time."
    else:
        reina "Think about it. I will be around."

    "She turns to leave."

    menu:
        "What do you do?"

        "Call after her: \"Wait.\"":
            $ reina_bond += 1
            mc "Wait."
            reina "Not yet. Not here."
            "She does not look back. But she slows down, just for a moment."

        "Let her go.":
            "She walks until the rain takes her edges away."

        "Watch where she goes.":
            $ evidence += 1
            "She reaches the corner. The streetlight above her flickers."
            "When it steadies, the corner is empty."

    hide reina with dissolve

    "Behind you, the archive door is still lit."
    "Whatever you decide next, you decide it alone."

    scene black with fade
    "End of Chapter 1."

    jump chapter2
