# chapter2.rpy - SEMENTARA (stub) sampai Tahap 5

label chapter2:

    $ current_chapter = "Chapter 2"

    scene bg archive with fade

    "Chapter 2 will be written in Stage 5."
    "Debug: evidence=[evidence], reina_bond=[reina_bond], arman_susp=[arman_susp], independence=[independence]."
    "Debug: clue_letter=[clue_letter], clue_log=[clue_log], got_slip=[got_slip], shared_with_reina=[shared_with_reina]."

    return
