# characters.rpy - definisi karakter (gaya bicara dibedakan lewat warna dan penulisan)

define mc = Character("[pname]", color="#c9d1d9")
define arman = Character("Arman", color="#8fa8c8")
define reina = Character("Reina", color="#d0505f")

# Latar "bg room" untuk Prologue (polos). Latar TV rusak ada di images.rpy
image bg room = Solid("#14161c")
