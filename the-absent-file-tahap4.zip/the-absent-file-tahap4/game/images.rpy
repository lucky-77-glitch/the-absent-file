# images.rpy - gambar SEMENTARA (placeholder). Ganti dengan aset milik sendiri nanti.
# Latar: layar TV rusak. Karakter: siluet hitam bermata merah dengan efek glitch.
# Animasi dibuat lambat dan redup agar tidak terlalu berkedip.

image bg archive:
    "images/bg_tv_a1.png"
    pause 0.25
    "images/bg_tv_a2.png"
    pause 0.20
    "images/bg_tv_a3.png"
    pause 0.30
    repeat

image bg street:
    "images/bg_tv_b1.png"
    pause 0.25
    "images/bg_tv_b2.png"
    pause 0.20
    "images/bg_tv_b3.png"
    pause 0.30
    repeat

image arman:
    "images/spr_arman1.png"
    pause 1.2
    "images/spr_arman2.png"
    pause 0.08
    "images/spr_arman1.png"
    pause 0.8
    "images/spr_arman3.png"
    pause 0.06
    repeat

image reina:
    "images/spr_reina1.png"
    pause 1.0
    "images/spr_reina2.png"
    pause 0.08
    "images/spr_reina3.png"
    pause 0.7
    "images/spr_reina1.png"
    pause 0.06
    repeat
